package com.personal.expensestracker;

import com.getcapacitor.BridgeActivity;

public class MainActivity extends BridgeActivity {}
