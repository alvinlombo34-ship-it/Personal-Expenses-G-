# Personal Expenses Tracker — phone app project

The app is the file `www/index.html`. The `android` and `ios` folders wrap it as real native apps.

## Android: get an APK with GitHub (free, no software needed)
1. Create a free account at github.com, then click **New repository** (any name, Private is fine).
2. On the new repository page, click **uploading an existing file**, drag in everything from this folder
   (including the hidden `.github` folder), and click **Commit changes**.
   - If the `.github` folder doesn't upload, create the file `.github/workflows/build-android.yml`
     with **Add file → Create new file** and paste its contents.
3. Open the **Actions** tab. A build named "Build Android app" starts (about 5 minutes).
4. When it shows a green check, open it and download **Personal-Expenses-Tracker-Android** at the bottom.
5. Unzip it, send `app-debug.apk` to your Android phone, tap it, and allow "Install unknown apps".

## iPhone (needs a Mac)
Apple only allows iPhone apps to be built on a Mac with Xcode.
1. On a Mac, install Xcode (App Store), Node.js (nodejs.org), and CocoaPods (`sudo gem install cocoapods`).
2. In Terminal, inside this folder: `npm install` then `npx cap sync ios` then `npx cap open ios`.
3. In Xcode: select the **App** target → **Signing & Capabilities** → sign in with your Apple ID as the Team.
4. Plug in your iPhone, choose it at the top, and press ▶ Run.
   - Free Apple ID: the app works for 7 days, then re-run from Xcode.
   - Apple Developer Program ($99/year): needed for the App Store, TestFlight, or longer installs.

## Changing the app later
Edit `www/index.html`, then run `npx cap sync` (or just push to GitHub for Android).
App ID: `com.personal.expensestracker` · Name under icon: "Expenses".
